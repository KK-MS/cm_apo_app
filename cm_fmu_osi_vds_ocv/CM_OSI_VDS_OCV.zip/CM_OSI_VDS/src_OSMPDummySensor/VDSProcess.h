/*
 * VDSProcess.h
 *
 * Video data stream header file
 */

#ifndef _VDS_PROCESS_H
#define _VDS_PROCESS_H
/**********************************
 * Macros definations
 *********************************/ 
//#define VDS (1u)  //defined in makefile CFLAGS

/**********************************
 * Function prototypes
 *********************************/ 

/*
 * Initialize VDS 
 */
int VDS_doInit();

/*
 * Start capturing the VDS
 */
int VDS_Start(void);

/*
 * Free VDS resources
 */
int VDS_DoFree(void);

#endif //_VDS_PROCESS_H
