/*
 ******************************************************************************
 **  OpenCV function to process the video frame
 **
 **  Copyright (C)   A Drive, LivingLab, Kempten University
 **                  Germany
 ******************************************************************************
 **
 ** Process the image data 
 */

#include <opencv2/opencv.hpp>
#include <stdlib.h>

using namespace cv;
using namespace std;

/* GLOBAL VARIABLES */
//Mat imgIn;  /** Input Matrix  */
//Mat imgOut; /** Output Matrix */

/* FUNCTIONS */
void OCV_doInit(void)
{
	namedWindow("Received", WINDOW_AUTOSIZE );
	namedWindow("Edge detection", WINDOW_AUTOSIZE );
}

/**
 * Close the opencv processing and resources
 * Input: void
 * Return: void
 */
void OCV_Close(void)
{
	destroyWindow("Received");
	destroyWindow("Edge detection");
}

/**
 * Close the opencv processing and resources
 *
 * Input: iHeight  height of the frame
 *        iWidth   Width of the frame
 *        iFormat  Channels of the frame, RGB => 3
 *        pImgBuff pointer to the raw data
 *
 * Return: 0=>success, else failure
 */
int OCVFrameProcess(int iHeight, int iWidth, int iFormat, char *pImgBuff)
{
	Mat imgIn;  /** Input Matrix  */
	Mat imgOut; /** Output Matrix */

    if (imgIn.data == NULL) {
        imgIn.create(iHeight, iWidth, CV_8UC3);
    }
    memcpy(imgIn.data, pImgBuff, iHeight * iWidth * iFormat);

    cvtColor(imgIn, imgIn, COLOR_RGB2BGR);

	Canny(imgIn, imgOut, 100, 300); //, 3);

    imshow("Received", imgIn);
    imshow("Edge detection", imgOut);

    waitKey(10);

    imgIn.release();
    imgOut.release();

    return 0;
}

