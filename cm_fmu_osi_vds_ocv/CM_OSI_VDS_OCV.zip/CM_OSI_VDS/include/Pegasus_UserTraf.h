
#ifndef PEGASUS_USERTRAF_H_
#define PEGASUS_USERTRAF_H_

/*================================User Manual====================================
 *
 * Step 1: Run Converter to get the CarMaker info-file and Road5-file
 * Step 2: Get the lib file libpegasus_<version>.a and put the following in Makefile
 * 		...
 *
 * 		OBJS +=	pegasuslib_win32.a
 *
 * 		...
 * Step 3: Put the functions at the right position in User.c
 *		#include "Pegasus_UserTraf.h"
 *		...
 *
 *	  	int
 *		User_TestRun_Start_atBegin (void)
 *		{
 *		...
 *			UserTraffic_New(SimCore.TestRun.Inf);
 *		...
 *
 *		}
 *
 *		...
 *
 *		int
 *		User_Traffic_Calc (double dt)
 *		{
 *		...
 *			UserTraffic_Calc();
 *		...
 *		}
 * Step 4: Compile the project
 * Step 5: Load the executable in CarMaker Gui or choose the project 
 * 	   diretory in Matlab and run the Testrun.
 *==============================================================================*/

typedef enum tManLongMode {

	LongMode_none 	= 0,
	LongMode_speed 	= 1

}tManLongMode;

typedef enum tManLatMode {

	LatMode_none 	   = 0,
	LatMode_laneChange = 1

}tManLatMode;
typedef struct tPrivAction {

	double f1,f2,f3,f4,f5,f6;
	int d1,d2,d3,d4,d5,d6;
	char str1[128],str2[128],str3[128];

}tPrivAction;

typedef struct tUserManeuver {

	tManLongMode longMode;
	tManLatMode latMode;
	tPrivAction LongAction;
	tPrivAction LatAction;
	double acc,vel;

}tUserManeuver;

typedef struct tUserTrafficObj{

	int nMans;
	tUserManeuver *userMan;
	int manNo_old;
	double sRoad_start,tRoad_start, vel_start, acc_start, dis_start;
	double sRoad_len_old,tRoad_len_old, vel_old,tRoad_old;

}tUserTrafficObj;

typedef struct tUserTraffic{

	int nObjs;
	tUserTrafficObj *userTrafficObj;

}tUserTraffic;

/*
** UserTraffic_New ()
**
** search the traffic object
**
** Call:
** - at User_TestRun_Start_atBegin()
*/
int UserTraffic_New(tInfos *Inf);

/*
** UserTraffic_Calc ()
**
** get all traffic objects within one cycle
**
** Call:
** - at User_Traffic_Calc()
*/
int UserTraffic_Calc(void);


#endif /* PEGASUS_USERTRAF_H_ */
