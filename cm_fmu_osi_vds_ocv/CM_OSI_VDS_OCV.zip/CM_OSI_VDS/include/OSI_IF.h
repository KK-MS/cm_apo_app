

int Init_OSI (void);
int Delete_OSI (void);
void CreateSensorData (void **const addr, int32_t *const size);
void ReleaseSensorData (void *addr);
